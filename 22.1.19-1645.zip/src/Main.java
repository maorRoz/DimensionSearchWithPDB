import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Main {

    public static void main(String[] args) {
//		long start = System.currentTimeMillis();
        System.out.println("Start!");


        AStarSearch astar = new AStarSearch();
        GameGrid2D play = MapFileLoader.loadMapFile("C:\\Users\\tal.BGU-USERS.000\\Downloads\\arena.map");
        solveInstances(astar, play.gettheGrid(), new HitmapHeuristic(play.gettheGrid(),1,7));

        play = MapFileLoader.loadMapFile("C:\\Users\\tal.BGU-USERS.000\\Downloads\\arena.map");
        astar = new AStarSearch();
        solveInstances(astar,play.gettheGrid() , new ManhattanDistanceHeuristic());


        play = MapFileLoader.loadMapFile("C:\\Users\\tal.BGU-USERS.000\\Downloads\\arena.map");
        astar = new AStarSearch();
        solveInstances(astar, play.gettheGrid(), new AirGapDistanceHeuristic());


        System.out.println("");
        System.out.println("Done!");
//		System.out.println("time: "+(System.currentTimeMillis() - start));
    }


    public static void solveInstances(ASearch solvers, int [][] instance, IHeuristic heuristic) {

            long totalTime = 0;

                Map problem = new Map(instance,1,46,1,7, heuristic);

                    long startTime = System.nanoTime();
                    List<IProblemMove> solution = solvers.solve(problem);
                    long finishTime = System.nanoTime();

                  //  if (cost >= 0)        // valid solution
                    {
                        // printSolution(problem, solution);

                        System.out.println("Moves: " + solution.size());
                        System.out.println("Time:  " + (finishTime - startTime) / 1000000.0 + " ms");
                       // System.out.println(solution);
                        totalTime += (finishTime - startTime) / 1000000.0;
                    }// else                // invalid solution
                      //  System.out.println("Invalid solution.");

                System.out.println("");

            System.out.println("Total time:  " + totalTime / 60000.0 + " min");
            System.out.println("");

    }

    public static List<String> getInstances(String type) throws IOException {
        List<String> instances = new ArrayList<String>();
        String currentDir = new java.io.File(".").getCanonicalPath() + "\\instances\\" + type + "\\";
        File folder = new File(currentDir);
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                instances.add(currentDir + listOfFiles[i].getName());
            }
        }
        return instances;
    }




}
