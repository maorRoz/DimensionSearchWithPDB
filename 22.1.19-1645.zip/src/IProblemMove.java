
public interface IProblemMove 
{

}
