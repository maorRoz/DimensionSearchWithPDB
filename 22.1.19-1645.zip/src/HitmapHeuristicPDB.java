public  class HitmapHeuristicPDB implements IHeuristic {
   // <int[][]> hitMap;

    HitmapHeuristicPDB(int[][] map) {

    }

    public double getHeuristic(IProblemState problemState) {
        int h = 0;
        MapState state = (MapState) problemState;
      //  h = hitMap[state._currentCol][state._currentRow];
        return h;
    }


    public int[][] calcHitmap(int[][] domain, int pivotRow, int pivotCol) {

        return null;


    }

    @Override
    public void HeuristicName() {
        System.out.println("-----------------------------------");
        System.out.println("HitmapHeuristic:");
    }
}
