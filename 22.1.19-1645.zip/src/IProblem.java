
public interface IProblem 
{
	public IProblemState		getProblemState();
	
	public IHeuristic			getProblemHeuristic();



}

