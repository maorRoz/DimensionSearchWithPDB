public class HitmapHeuristicPDB implements IHeuristic {
    HitmapHeuristic[][] hitMapPDB;

    HitmapHeuristicPDB(int[][] map) {
        hitMapPDB = new HitmapHeuristic[map.length][map[0].length];
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] == 0)
                    hitMapPDB[i][j] = new HitmapHeuristic(map, i, j);


            }

        }

    }
    public double getHeuristic(IProblemState problemState) {
        double h = 0;
        MapState state = (MapState) problemState;
        h = hitMapPDB[state._problem._goalRow][state._problem._goalCol].getHeuristic(problemState);
        return h;
    }


    public int[][] calcHitmap(int[][] domain, int pivotRow, int pivotCol) {

        return null;


    }

    @Override
    public void HeuristicName() {
        System.out.println("-----------------------------------");
        System.out.println("HitmapHeuristic via PDB:");
    }
}
