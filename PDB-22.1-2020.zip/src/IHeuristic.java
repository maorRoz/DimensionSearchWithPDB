
public interface IHeuristic 
{
	public double getHeuristic(IProblemState problemState);
	public void HeuristicName();
}
