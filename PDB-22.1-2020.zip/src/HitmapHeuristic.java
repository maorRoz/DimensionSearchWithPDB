public class HitmapHeuristic implements IHeuristic {
        int[][] hitMap;

    HitmapHeuristic(int[][] map, int pivotRow, int pivotCol) {
        DijkstraSearch dijkstraSearch = new DijkstraSearch();
        HeatMap2D heatMap2D = dijkstraSearch.search( map,pivotRow, pivotCol);
        hitMap = heatMap2D.getMap();


     // printHitmap();
    }

    private void printHitmap() {
        for (int i = 0; i <hitMap.length ; i++) {
            for (int j = 0; j <hitMap.length ; j++) {
                System.out.print(hitMap[i][j]+",");

            }
            System.out.println();

        }
    }

    public double getHeuristic(IProblemState problemState) {
        int h = 0;
        MapState state = (MapState) problemState;
        h = hitMap[state._currentRow][state._currentCol];
        return h;
    }

    @Override
    public void HeuristicName() {
        System.out.println("-----------------------------------");
        System.out.println("HitmapHeuristic:");
    }






    public int[][] calcHitmapOLD(int[][] domain, int pivotRow, int pivotCol) {

        return new int[][]
                {{600, 600, 600, 6}};

    }


}
